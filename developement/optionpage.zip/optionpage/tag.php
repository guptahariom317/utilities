<?php
/**
 * The template for displaying Tag pages.
 *
 * Used to display archive-type pages for posts in a tag.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Thirteen
 * @since Twenty Thirteen 1.0
 */

get_header(); ?>

<div class="wrapper">
      <div class="inner_welcome_inner">
      <?php $id=17; $post = get_page($id); echo $post->post_content;  ?>
        
      </div>
    </div>
  </div>
   <div class="wrapper">
    <div class="blog_left">
    	<ul>
		<?php if ( have_posts() ) : ?>
			
				<h1 class="archive-title"><?php printf( __( 'Tag Archives: %s', 'twentythirteen' ), single_tag_title( '', false ) ); ?></h1>

				<?php if ( tag_description() ) : // Show an optional tag description ?>
				<div class="archive-meta"><?php echo tag_description(); ?></div>
				<?php endif; ?>
			
			<?php /* The loop */ ?>
			<?php while ( have_posts() ) : the_post(); ?>
				<?php get_template_part( 'content', get_post_format() ); ?>
			<?php endwhile; ?>

			<?php //twentythirteen_paging_nav(); ?>

		<?php else : ?>
			<?php get_template_part( 'content', 'none' ); ?>
		<?php endif; ?>
          <div class="clear"></div>
         <?php if(function_exists('wp_paginate')) {
    wp_paginate();
} ?>
		</ul>
      </div>
        <!--sidebar start-->
		<?php get_sidebar('blog'); ?>
    <!--sidebar end-->
    </div>
 
  
    </div>
</section>
<?php get_footer(); ?>