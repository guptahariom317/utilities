=== WooCommerce Tab Manager ===
Author: skyverge
Tags: woocommerce
Requires at least: 3.8
Tested up to: 4.0
Requires WooCommerce at least: 2.1
Tested WooCommerce up to: 2.2

A product tab manager for WooCommerce

See http://docs.woothemes.com/document/tab-manager/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-tab-manager' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
