<?php
function karma_widgets_init() {

}
add_action( 'widgets_init', 'karma_widgets_init' );
?>