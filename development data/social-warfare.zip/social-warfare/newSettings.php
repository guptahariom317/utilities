<?php

	require_once('admin-page-class/admin-page-class.php');
	
	$config = array(
    'menu'=> array('top' => 'social-warfare'),  	// sub page to settings page
    'page_title' => 'Social Warfare',   			// The name of this page
    'capability' => 'update_plugins',       		// The capability needed to view the page
    'option_group' => 'socialWarfareOptions',		// the name of the option to create in the database
    'id' => 'social-warfare',                		// Page id, unique per page
    'fields' => array(),                 			// list of fields (can be added by field arrays)
    'local_images' => false,             			// Use local or hosted images (meta box images for add/remove)
    'use_with_theme' => false            			// change path if used with theme set to true, false for a plugin or anything else for a custom path(default false).
); 

	$options_panel = new BF_Admin_Page_Class($config);

	$options_panel->OpenTabs_container('');
	$options_panel->TabsListing(array(
		'links' => array(
		'options_1' => __('Display Settings'),
		'options_2' => __('Visual Options'),
		'options_3' => __('Click to Quote'),
		'options_4' => __('Register'),
		'options_5' => __('System Status'),
		'options_6' => __('Help / FAQ'),
		'options_7' => __('Advanced Usage')
		)
	));
	
	$options_panel->OpenTab('options_1');
	
	$options_panel->Title("Display Settings");
	//An optional description paragraph
	$options_panel->addParagraph("Welcome to Social Warfare! Get ready to dominate the world's social networks. This is the page where you'll select which social media icons to display, where to display them, and in what order.");

	$contentLocations = array('above'=>'Above the Content','below' => 'Below the Content', 'both' => 'Both Above and Below the Content', 'none' => 'None/Manual Placement');
	$options_panel->addParagraph("<h3>Where would you like to display your share buttons?</h3>If you select 'None/Manual Placement' you can add the social warfare plugin by adding 'socialWarfare()' to your themes files at the specific location that you want it to appear.");
	$options_panel->addSelect('locationPost',$contentLocations,array('name'=> 'Location on Posts', 'std'=> array('both')));
	$options_panel->addSelect('locationPage',$contentLocations,array('name'=> 'Location on Pages', 'std'=> array('both')));
	$options_panel->addSelect('locationSite',$contentLocations,array('name'=> 'Location Sitewide', 'std'=> array('below')));
	$options_panel->addParagraph("<h3>Would you like to be mentioned in tweets?</h3><br />If so, please provide your Twitter username WITHOUT the @ symbol.");
	$options_panel->addText('twitterID',array('name'=> 'Twitter Username'));
	$options_panel->addParagraph("<h3>Which social media icons would you like to display?</h3>");
	$options_panel->addCheckbox('googlePlus',array('name' => 'Google Plus', 'googlePlus'=> 'googlePlus', 'std' => '1'));
	$options_panel->addCheckbox('twitter',array('name' => 'Twitter', 'twitter'=> 'twitter', 'std' => '1'));
	$options_panel->addCheckbox('facebook',array('name' => 'Facebook', 'facebook'=> 'facebook', 'std' => '1'));
	$options_panel->addCheckbox('pinterest',array('name' => 'Pinterest', 'pinterest'=> 'pinterest', 'std' => '1'));
	$options_panel->addCheckbox('linkedIn',array('name' => 'LinkedIn', 'linkedIn'=> 'linkedIn', 'std' => '1'));
	$options_panel->addCheckbox('totes',array('name' => 'Total Shares', 'totes'=> 'totes', 'std' => '1'));
	$options_panel->addParagraph("<h3>In what order should we place your share buttons?</h3><br />Simply drag and drop the social platforms to indicate the order in which you want them displayed. ");
	$options_panel->addSortable('orderOfIcons',array('googlePlus'=>'Google Plus','Twitter'=>'Twitter','Facebook'=>'Facebook','Pinterest'=>'Pinterest','LinkedIn'=>'LinkedIn'),array('name' => 'Order of Icons'));
	// Close first tab
	$options_panel->CloseTab();
	
	// Open admin page Second tab
	$options_panel->OpenTab('options_2');
	$options_panel->Title("Visual Options");	
	$visualOptions = array('style1' => 'Flat & Fresh');
	$options_panel->addSelect('visualTheme',$visualOptions,array('name'=> 'Visual Theme', 'std'=> array('style1')));
	$colorSets		= array('fullColor' => 'Full Color', 'fade' => 'Fade','grayscale' => 'Grayscale' );
	$options_panel->addSelect('colorSet',$colorSets,array('name'=> 'Color Set', 'std'=> array('fullColor')));
	$options_panel->addParagraph('Select the number of decimals to display on numbers greater than 1,000. Zero will display as 3K shares. One will display as 3.2K shares. Two will display as 3.24K Shares. We recommend one.');
	$options_panel->addSelect('swDecimals',array('0'=>'Zero','1'=>'One','2'=>'Two'),array('name'=> 'Decimals', 'std'=> array('0')));
	$options_panel->addParagraph('<h3>Available Icon Sets</h3>Flat & Fresh<br /><img src="'.PLUGIN_DIR.'/images/style1-demo.png">');
	$options_panel->addCheckbox('float',array('name' => 'Floating Share Buttons?', 'float'=> 'float', 'std' => '1'));
	$floatOptions = array('top' => 'Top of the Page', 'bottom' => 'Bottom of the Page','left' => 'On the left side of the page' );
	$options_panel->addSelect('floatOption',$floatOptions,array('name'=> 'Float Position', 'std'=> array('bottom')));
	$options_panel->addColor('floatBgColor',array('name'=> 'Floating Background Color', 'std' => '#ffffff'));

	
 
	$options_panel->CloseTab();
	
	// Open admin page 3rd tab
	$options_panel->OpenTab('options_3');
	$options_panel->Title('Click to Tweet');	
	$cttOptions = array('style1' => 'Send Her My Love', 'style2' => 'Roll With The Changes', 'style3' => 'Free Bird', 'none' => 'None - Create Your Own CSS In Your Theme');
	$options_panel->addSelect('cttTheme',$cttOptions,array('name'=> 'Visual Theme', 'std'=> array('style1')));
	$options_panel->Title('Available Styles');
	$options_panel->addParagraph('<h4>Send Her My Love</h4><img src="'.PLUGIN_DIR.'/images/cttStyle1-demo.jpg"></p>');
	$options_panel->addParagraph('<h4>Roll With The Changes</h4><img src="'.PLUGIN_DIR.'/images/cttStyle2-demo.jpg"></p>');
	$options_panel->addParagraph('<h4>Free Bird</h4><img src="'.PLUGIN_DIR.'/images/cttStyle3-demo.jpg"></p>');

	$options_panel->CloseTab();
	 
	// Open admin page 4th tab
	
	$options_panel->OpenTab('options_4');
	/**
	* Add fields to your admin page 4th tab
	*
	* WordPress Options:
	* Taxonomies dropdown
	* posts dropdown
	* Taxonomies checkboxes list
	* posts checkboxes list
	*
	*/
	//title
	$regCode = md5(get_home_url());
	$options_panel->Title("Premium Registration");
	if(is_sw_registered()):
		$options_panel->addParagraph('<span style="color:green"><b>This copy of Social Warfare IS registered.</b></span>');
	else:
		$options_panel->addParagraph('<span style="color:#ed464f"><b>This copy of Social Warfare IS NOT registered.</b></span>');
	endif;
	$options_panel->addParagraph('To register the plugin to this site, simply follow the steps below.<br /><br />1. Provide the email address that you used at the time of purchase.<br />2. Click on the "Activate Plugin" button. The remaining fields should automatically populate.<br />3. Click "Save Changes" at the bottom of this page.');
	$options_panel->addParagraph('
	<div class="at-label"><label for="regCode">Registration Code</label></div><input type="text" class="at-text" name="regCode" id="regCode" value="'.$regCode.'" size="30" readonly><input type="hidden" class="at-text" name="domain" id="domain" value="'.get_home_url().'" size="30" readonly><div class="clearfix"></div>
	');
	$options_panel->addText('emailAddress',array('name'=> 'Email Address'));
	$options_panel->addText('premiumCode',array('name'=> 'Premium Code'));
	$options_panel->addParagraph('<input type="submit" class="activate btn-info" value="Activate Plugin" />');
	$options_panel->addParagraph('To unregister the plugin from this site, simply click the unregister button below and then click "Save Changes" at the bottom of this page. This will disable it\'s functionality on this site, but will allow you to register this plugin to a different domain.');
	$options_panel->addParagraph('<input type="submit" class="deactivate btn-info" value="Deactivate Plugin" />');
	
	$options_panel->CloseTab();
	$options_panel->OpenTab('options_5');
	$options_panel->Title("System Status");
	
	// Gather the settings to display on the screen
	/*
	$social 				= new shareCount('http://dustn.tv/find-free-images/');
	$status['twitter'] 		= $social->get_tweets();
	$status['facebook'] 	= $social->get_fb(); 
	$status['google'] 		= $social->get_plusones();
	$status['pinterest'] 	= $social->get_pinterest();
	$status['linkedin'] 	= $social->get_linkedin();
	
	foreach ( $status as $key => $value ):
		if($value > 0):
			$status[$key] = '<span style="color:green;">Connected</span>';
		else:
			$status[$key] = '<span style="color:red;">Connection Blocked</span>';
		endif;
	endforeach; */
	if ( ! function_exists( 'get_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	$plugins = get_plugins();
	$pluginList = '';
	foreach ($plugins as $plugin):
		$pluginList .= '<tr><td><b>'.$plugin['Name'].'</b></td><td>'.$plugin['Version'].'</td></tr>';
	endforeach;
	
	if ( function_exists('fsockopen') ) :
        $fsockopen = '<span style="color:green;">Enabled</span>';
    else :
		$fsockopen = '<span style="color:red;">Disabled</span>';
    endif;
	
	if ( function_exists('curl_version') ) :
        $curl = '<span style="color:green;">Enabled</span>';
    else :
		$curl = '<span style="color:red;">Disabled</span>';
    endif;
	
	$theme = wp_get_theme();
	
	$options_panel->addParagraph('
		<p>Please include all of the information on this page when reporting bugs or glitches. This will help us to more quickly identify any conflicts that may be interfering with the functioning of this plugin.</p>
		<table style="width:100%;">
			<tr><td><h2>Environment Statuses</h2></td><td></td></tr>
			<tr><td><b>Home URL</b></td><td>'.get_home_url().'</td></tr>
			<tr><td><b>Site URL</b></td><td>'.get_site_url().'</td></tr>
			<tr><td><b>WordPress Version</b></td><td>'.get_bloginfo('version').'</td></tr>
			<tr><td><b>PHP Version</b></td><td>'.phpversion().'</td></tr>
			<tr><td><b>WP Memory Limit</b></td><td>'.WP_MEMORY_LIMIT.'</td></tr>
			<tr><td><b>Social Warfare Version</b></td><td>'.$pluginVersion.'</td></tr>
			<tr><td><h2>Connection Statuses</h2></td><td></td></tr>
			<tr><td><b>fsockopen</b></td><td>'.$fsockopen.'</td></tr>
			<tr><td><b>cURL</b></td><td>'.$curl.'</td></tr><!--
			<tr><td><b>Twitter Connection Status</b></td><td>'.$status['twitter'].'</td></tr>
			<tr><td><b>Facebook Connection Status</b></td><td>'.$status['facebook'].'</td></tr>
			<tr><td><b>Google Plus Connection Status</b></td><td>'.$status['google'].'</td></tr>
			<tr><td><b>Pinterest Connection Status</b></td><td>'.$status['pinterest'].'</td></tr>
			<tr><td><b>LinkedIn Connection Status</b></td><td>'.$status['linkedin'].'</td></tr>-->
			<tr><td><h2>Plugin Statuses</h2></td><td></td></tr>
			<tr><td><b>Theme Name</b></td><td>'.$theme['Name'].'</td></tr>
			<tr><td><b>Theme Version</b></td><td>'.$theme['Version'].'</td></tr>
			<tr><td><b>Active Plugins</b></td><td></td></tr>
			<tr><td><b>Number of Active Plugins</b></td><td>'.count($plugins).'</td></tr>
			'.$pluginList.'
			
		</table>
	');
	$options_panel->CloseTab();
	$options_panel->OpenTab('options_6');
	$options_panel->Title("Help & Frequently Asked Questions");
	$options_panel->addParagraph('
		<p>1. Who should I contact if I need help?</p>
		<p>2. I just shared the post but the numbers didn\'t update. Why not?</p>
		<p>3. How do I use the "Click to Tweet" function?</p>
		<p>4. I just upgraded and now it is not working properly. How do I fix this?</p>
	');
	$options_panel->addParagraph('<h2>1. Who should I contact if I need help?</h2><p>Please contact us using the <a href="http://warfareplugins.com/contact-us/">Contact Form</a> on the Warfare Plugins website.</p></p>Nicholas Z. Cardot is the lead developer on this project, and, in most situations, will be the the one most likely to be able to provide assistance. Reach out to him using the contact form mentioned above.</p><p>When you reach out, please have the information from the System Status page ready to provide. In fact, it would be super helpful if you just go ahead and paste it into the initial message that you send.</p>');
	$options_panel->addParagraph('<h2>2. I just shared the post but the numbers didn\'t update. Why not?</h2><p>In an effort to supercharge the load speed of the plugin and to allow for the sorting of posts by their popularity, we cache (temporarily store) the share counts with the post in WordPress. These numbers are updates on the following timescales:</p>
	<table style="width:100%;">
	<tr><td><b>Post Age</b></td><td><b>Numbers Update:</b></td></tr>
	<tr><td>New Posts</td><td>Once Every 1 Hour</td></tr>
	<tr><td>Posts Older Than 3 Weeks</td><td>Once Every 3 Hours</td></tr>
	<tr><td>Posts Older Than 2 Months</td><td>Once Every 6 Hours</td></tr>
	</table>');
	$options_panel->addParagraph('<h2>3. How do I use the "Click to Tweet" function?</h2><p>When editing a post or page, simply click on the button with the Twitter icon in the toolbar. A popup will appear requiring you to populate two fields. One is the field for the actual tweet that will be shared to Twitter. The other is the quote as it will appear in the article. We have designed it this way, because the 140 character limit on Twitter means that sometimes the tweet will be a slightly modified, shortened version of the actual quote.</p><p>Character counting begins at 117 characters because we take into account the t.co links that Twitter uses to wrap the link. The link will be automatically added by the Social Warfare plugin. There is no need to add one yourself in that field.</p><p>P.S. This feature used features that were introduced into the WordPress core very, very recently. You\'ll need to be sure that you\'re using WordPress 4.0 or newer for this to work.</p>');
	$options_panel->addParagraph('<h2>4. I just upgraded and now it is not working properly. How do I fix this?</h2><p>Sometimes, after upgrading, new settings are introduced to the plugin. This means that since the plugins settings have not been saved, no options have been set for the newly introduced settings. Simply go to the Social Warfare settings page (the one your on right now) and click the save button at the bottom of the page. If a problem persists after having done that, be sure to get in touch with us.</p>');
	$options_panel->CloseTab();
	
	
	$options_panel->OpenTab('options_7');
	$options_panel->Title("Advanced Usage");
	$options_panel->addParagraph('<h2>Manually Adding Social Warfare to your Theme</h2><p>Before manually adding Social Warfare to your theme, be sure to change the placement settings for that area of your site to "None/Manual Placement". It does not display well when the automatically added version of the plugin and the manually added version exist on the same page.</p><p>Once that setting has been changed, you can manually add the plugin by simply adding the socialWarfare() function wherever you want it to display.</p><p>You can also add the share buttons inside of a post by using the [socialWarfare] shortcode.</p><p><b>Disclaimer:</b> The team at Social Warfare highly recommend that any changes made to your theme be added in the form of a Child Theme. This will allow you to preserve your edits after updating the parent theme.</p>');
	$options_panel->addParagraph('<h2>Sorting Posts Based on Popularity</h2><p>Social Warfare comes equipped with a popular posts widget that you can easily add to your sidebar. However, should you desire, you can also have a developer manipulate a loop (perhaps on a custom post type for a contest) so that posts are sorted by their popularity.</p><p>		
		The following should show you how to manipulate the WordPress loop and sort your posts by displaying those that have been shared the most on top. The meta_key is a custom field that we populate with the total number of shares. Due to caching, this number is updated only once per hour.<br /><pre>
$args = array(
	"posts_per_page" => 10,
	"post_type" => "post",
	"meta_key" => "totes",
	"orderby" => "meta_value_num",
	"order" => "DESC"
);
$q = new WP_Query( $args );
if( $q->have_posts() ) :
	$i = 1;
	while( $q->have_posts() ):
		$q->the_post();
		< Post functions go here like title, content, excerpts, etc. >
	endwhile;
endif;
wp_reset_postdata();
</pre>
	');
	$options_panel->addParagraph('<h2></h2><p></p>');
	$options_panel->CloseTab();
?>