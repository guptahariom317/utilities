=== Plugin Name ===
Contributors: Nicholas Cardot
Tags: social media, social sharing
Requires at least: 3.0.1
Tested up to: 5.0.0
Stable tag: 4.3

Your Ultimate Social Sharing Arsenal

== Description ==

The description is going to go here eventually.

== Installation ==

1. Upload social-warfar.zip via the plugins page in the WordPress admin.
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

= What about foo bar? =

Answer to foo bar dilemma.

== Changelog ==

= 0.1 =
* This is the originally creates plugin

= 0.2 =
* Added the ability to automatically update the plugin from within the WordPress admin.

== Upgrade Notice ==

= 0.1 =
Yup. This one was cool. It was our initial launch.

= 0.2 =
Update to this one to enable automatic updating.