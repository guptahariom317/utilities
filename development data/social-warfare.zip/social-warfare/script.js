(function($) {
    var uniqueCntr = 0;
    $.fn.scrolled = function (waitTime, fn) {
        if (typeof waitTime === "function") {
            fn = waitTime;
            waitTime = 500;
        }
        var tag = "scrollTimer" + uniqueCntr++;
        this.scroll(function () {
            var self = $(this);
            var timer = self.data(tag);
            if (timer) {
                clearTimeout(timer);
            }
            timer = setTimeout(function () {
                self.removeData(tag);
                fn.call(self[0]);
            }, waitTime);
            self.data(tag, timer);
        });
    }
})(jQuery);
jQuery(document).on('click','.nc_tweet, .sw-click-to-tweet a',function(event) {
	  if(jQuery(this).hasClass('noPop')) {} else {
		  event.preventDefault();
		  href = jQuery(this).attr("data-link");
		  href = href.replace("’","'");
		  if (jQuery(this).hasClass("pinterest"))
		  {
				height = 550;
				width = 700;
		  }
		  else
		  {
				height = 270;
				width = 500;
		  }
		  	instance = window.open("about:blank", "_blank", "height=" + height + ",width=" + width);
		  	instance.document.write("<meta http-equiv=\"refresh\" content=\"0;url="+href+"\">");
    		instance.document.close();
    		return false;
	  }
});
function isOdd(num) { return num % 2;} 

function setWidths(resize) {
	if(typeof resized === 'undefined' || resize) { 
		var totalWidth 	= jQuery('.nc_socialPanel').width() - 2;
		var totalElements	= jQuery('.nc_socialPanel').attr('data-count');
		var average = parseInt(totalWidth) / parseInt(totalElements);
		var space = parseInt(totalWidth) - parseInt(totalElements);
		if(totalWidth < 450) {
			var average = (parseInt(totalWidth) / (parseInt(totalElements) - 1)) - 10;
			var oddball = average * (totalElements - 1);
			var oddball = totalWidth - oddball;
			mobile = true;
			buttonWidths = 0;
			jQuery('.nc_tweetContainer.totes,.nc_tweetContainer .count').hide();
			jQuery('.nc_tweetContainer').each(function() {
				width = jQuery(this).find('.iconFiller').width();
				if(isOdd(average)) {
					marginLeft = Math.ceil((average - width) / 2);	
					marginRight = Math.floor((average - width) / 2);
				} else {
					marginLeft = (average - width) / 2;
					marginRight = (average - width) / 2;
				}
				jQuery(this).find('.iconFiller').css({'margin-left':marginLeft+'px','margin-right':marginRight+'px'});
			});
			// jQuery('.nc_tweetContainer').css({"padding-left":"4px","padding-right":"4px"});
		} else {
			mobile = false;
			jQuery('.nc_tweetContainer.totes,.nc_tweetContainer .count').show();
			jQuery('.nc_tweetContainer .iconFiller').css({'margin-left':'0px','margin-right':'0px'});
			var average = Math.floor(average);
			var oddball = average * totalElements;
			var oddball = totalWidth - oddball;
			var totes = jQuery('.totes').outerWidth(true);
			if(totes > average) {
				newTotalWidth = totalWidth - totes;
				average = parseInt(newTotalWidth) / parseInt(totalElements - 1);
				average = Math.floor(average);
				oddball = average * (totalElements - 1);
				oddball = newTotalWidth - oddball;
			}
			count = 0;
			window.origSets = new Array();
			jQuery('.nc_socialPanel .nc_tweetContainer').each(function() {
				++count; 
				if(count > totalElements) {count = 1;}
				if(count <= oddball){add = 1} else {add = 2};
				curWidth = jQuery(this).outerWidth(true);
				dif = average - curWidth;
				dataId = jQuery(this).attr('data-id');
				dataId = parseInt(dataId);
				window.origSets[dataId] = new Array();
				if(isOdd(dif)){ 
					dif = dif - 1;
					dif = dif / 2;
					pl = dif+1+average;
					pr = dif+average;
					window.origSets[dataId]['pl'] = dif+1+'px';
					window.origSets[dataId]['pr'] = dif+'px';
					window.origSets[dataId]['fil'] = jQuery(this).find('.iconFiller').width();
					jQuery(this).find('.count').animate({
						"padding-left": "+="+(dif+1)+"px",
						"padding-right": "+="+dif+"px"
						}, 50, "linear", function() {		
							jQuery(this).css({transition : 'padding .1s linear'});		
						});
				} else {
					dif = dif / 2;
					pl = dif+average;
					pr = dif+average;
					window.origSets[dataId]['pl'] = dif+'px';
					window.origSets[dataId]['pr'] = dif+'px';
					window.origSets[dataId]['fil'] = jQuery(this).find('.iconFiller').width();
					jQuery(this).find('.count').animate({
						"padding-left": "+="+(dif)+"px",
						"padding-right": "+="+dif+"px"
						}, 50, "linear", function() {	
							jQuery(this).css({transition : 'padding .1s linear'});
						});	
				}
				resized = true;
			}); 
		}
	} else {
		jQuery('.nc_socialPanel .nc_tweetContainer').each(function() {
			dataId = parseInt(jQuery(this).attr('data-id'));
			jQuery(this).find('.iconFiller').css({"width":origSets[dataId]['fil']});
			jQuery(this).find('.count').css({
				"padding-left": origSets[dataId]['pl'],
				"padding-right":  origSets[dataId]['pr']
				});
		});	
	} 
};

function createFloatBar() {
	var firstSocialPanel = jQuery('.nc_socialPanel').first();
	var floatOption = firstSocialPanel.attr('data-float');
	if(floatOption) {
		backgroundColor = jQuery('.nc_socialPanel').attr('data-floatColor');
		jQuery('<div class="nc_wrapper" style="background-color:'+backgroundColor+'"></div>').appendTo('body');
		position = firstSocialPanel.attr('data-float');
		firstSocialPanel.clone().appendTo('.nc_wrapper');
		setWidths();
		jQuery('.nc_wrapper').hide().addClass(position);
		width = firstSocialPanel.outerWidth(true);
		offset = firstSocialPanel.offset();
		jQuery('.nc_socialPanel').last().addClass('nc_floater').css(
			{
				'width':width,
				'left':offset.left,
			})
		jQuery('.nc_socialPanel').eq(0).addClass('one');
		jQuery('.nc_socialPanel').eq(2).addClass('two');
		jQuery('.nc_socialPanel').eq(1).addClass('three');
		if(floatOption == 'floatBottom') {
			jQuery('body').animate({'padding-bottom': '+=50px'}, 0);
		};
	};
};
// Format Number functions
function ReplaceNumberWithCommas(nStr) {
  nStr += '';
  x = nStr.split('.');
  x1 = x[0];
  x2 = x.length > 1 ? '.' + x[1] : '';
  var rgx = /(\d+)(\d{3})/;
  while (rgx.test(x1)) {
    x1 = x1.replace(rgx, '$1' + ',' + '$2');
  }
  return x1 + x2;
}
function number_format( val ) {
    if( val < 1000 ){ 
	 	return ReplaceNumberWithCommas(val);
	 } else { 
	 	val = val/1000; 
		val = Math.round(val);
		return ReplaceNumberWithCommas(val)+'K';
	 }
}
// Twitter Shares Count

function floatingBar() {
	// Adjust the floating bar
	var panels = jQuery('.nc_socialPanel');
	var floatOption = panels.eq(0).attr('data-float');
	var windowElement = jQuery(window);
	var windowHeight = windowElement.height();
	var ncWrapper = jQuery('.nc_wrapper');
	var position = jQuery('.nc_socialPanel').attr('data-position');
	var lst = jQuery(window).scrollTop();
	jQuery(window).on('scroll', function() {
		offsetOne = panels.eq(0).offset();
		scrollPos = windowElement.scrollTop();
		var st = jQuery(this).scrollTop();
		if(floatOption == 'floatBottom') {
			if(position == 'both') {
				offsetTwo = panels.eq(1).offset();
				if(offsetOne.top < (scrollPos - 50) && offsetTwo.top > (scrollPos + windowHeight - 50) && st > lst) {
					ncWrapper.slideDown(); 
				} else if(offsetOne.top < (scrollPos - 50) && offsetTwo.top > (scrollPos + windowHeight - 50) && st < lst) {
					ncWrapper.show();
				} else if(offsetTwo.top < (scrollPos + (windowHeight / 2)) && offsetTwo.top > scrollPos ){
					ncWrapper.slideUp();
				} else if(offsetTwo.top < (scrollPos - 50)) {
					ncWrapper.slideDown();
				} else if(offsetTwo.top < (scrollPos + windowHeight - 50) && st > lst) {
					ncWrapper.hide();
				} else {
					ncWrapper.slideUp();
				}
			} else if(position == 'above') {
				if(offsetOne.top < (scrollPos - 60)) {
					ncWrapper.slideDown();	
				} else {
					ncWrapper.slideUp();
				}
			} else if(position == 'below') {	
				if(offsetOne.top > (scrollPos + windowHeight - 60)) {
					ncWrapper.filter(":hidden").show();
				} else if (offsetOne.top < (scrollPos - 60)) {
					ncWrapper.filter(":hidden").slideDown();
				} else if(offsetOne.top < scrollPos + (windowHeight / 2) ){
					ncWrapper.slideUp();
				} else {
					ncWrapper.hide();
				}
			
			}
		} else if(floatOption == 'floatTop') {
			if(position == 'both') {
				offsetTwo = panels.eq(1).offset();
				if(offsetOne.top < (scrollPos) && offsetTwo.top > (scrollPos + windowHeight) && st > lst) {
					ncWrapper.show(); 
				} else if(offsetOne.top < (scrollPos) && offsetTwo.top > (scrollPos + windowHeight) && st < lst) {
					ncWrapper.slideDown();
				} else if(offsetTwo.top < (scrollPos + (windowHeight / 2)) && offsetTwo.top > scrollPos ){
					ncWrapper.hide();
				} else if(offsetTwo.top < (scrollPos)) {
					ncWrapper.show();
				} else if(offsetTwo.top < (scrollPos + windowHeight) && st > lst) {
					ncWrapper.slideUp();
				} else {
					ncWrapper.hide();
				}
			} else if(position == 'above') {
				if(offsetOne.top < (scrollPos)) {
					ncWrapper.show();	
				} else {
					ncWrapper.hide();
				}
			} else if(position == 'below') {	
				if(offsetOne.top > (scrollPos + windowHeight)) {
					ncWrapper.filter(":hidden").slideDown();
				} else if (offsetOne.top < (scrollPos)) {
					ncWrapper.filter(":hidden").show();
				} else if(offsetOne.top < scrollPos + (windowHeight / 2) ){
					ncWrapper.hide();
				} else {
					ncWrapper.slideUp();
				}
			
			}
		}
		lst = st;
	});
};

function activateHoverStates() {
	if(mobile == false) {
		jQuery('.nc_tweetContainer').on("mouseenter",
			function() {
				thisElem 	= jQuery(this);
				tote 		= jQuery(this).attr('data-wid');
				dif 		= jQuery(this).attr('data-num');
				origDif		= dif;
				orig		= parseInt(tote) - parseInt(dif);
				ele			= jQuery('.nc_socialPanel').attr('data-count');
				dif 		= (parseInt(dif) / ((parseInt(ele)-2)));
				average 	= Math.floor(dif);
				oddball 	= average * (ele - 2);
				oddball 	= origDif - oddball;
				dataId = parseInt(jQuery(this).attr('data-id'));
				jQuery(this).find('.iconFiller').css({ "width":tote });
				pl = window.origSets[dataId]['pl'];
				pr = window.origSets[dataId]['pr'];
				jQuery(this).find('.count').css({
						"padding-left": pl,
						"padding-right": pr
					});
				dataId = jQuery(this).attr('data-id');
				count = 0;
				if(jQuery(this).hasClass('totes')) {
					jQuery(this).siblings('.nc_tweetContainer').each(function() {
						dataId = parseInt(jQuery(this).attr('data-id'));
						jQuery(this).find('.iconFiller').css({"width":window.origSets[dataId]['fil']});
						jQuery(this).find('.count').css({
							"padding-left": window.origSets[dataId]['pl'],
							"padding-right": window.origSets[dataId]['pr']
							});
					});
				} else {
					jQuery(this).siblings('.nc_tweetContainer').not('.totes').each(function() {
						++count;
						if(count <= oddball) {  ave = average + 1;
						} else { ave = average; };
						dataId = parseInt(jQuery(this).attr('data-id'));
						if(isOdd(ave)){
	
							offsetL = (((ave - 1) / 2) +1);
							offsetR = ((ave - 1) / 2);
							pl = parseInt(window.origSets[dataId]['pl']) - (((ave - 1) / 2) +1);
							pr = parseInt(window.origSets[dataId]['pr']) - ((ave - 1) / 2);
						} else {
	
							offsetL = (ave / 2);
							offsetR = (ave / 2 );
							pl = parseInt(window.origSets[dataId]['pl']) - (ave / 2);
							pr = parseInt(window.origSets[dataId]['pr']) - (ave / 2);
						}
						jQuery(this).find('.iconFiller').css({"width":origSets[dataId]['fil']});
						jQuery(this).find('.count').css({
							"padding-left": pl +"px",
							"padding-right": pr +"px"
							});
					});
				}
			}
		);
		jQuery('.nc_socialPanel').on("mouseleave", function() {
			setWidths();
		});
		jQuery('.fade .nc_tweetContainer').on("mouseenter", function() {
			jQuery(this).css({"opacity": 1 }).siblings('.nc_tweetContainer').css({"opacity": 0.6 });
		});
		jQuery('.fade').on("mouseleave", 
		function() {
			jQuery('.fade .nc_tweetContainer').css({"opacity": 1 });
		});
	}
}

function createTotal() {
	var tweets 		= jQuery('.twitter').attr('data-count');
	var linkshares	= jQuery('.linkedIn').attr('data-count');
	var pins 		= jQuery('.nc_pinterest').attr('data-count');
	var shares 		= jQuery('.fb').attr('data-count');
	var plusses 	= jQuery('.googlePlus').attr('data-count');	
	var total = parseInt(tweets) + parseInt(linkshares) + parseInt(pins) + parseInt(shares) + parseInt(plusses);
	jQuery('.totes .count').text(number_format(total)+' SHARES');
}

function retreiveShares(url) {
		
		// Get the Twitter Share Count
		jQuery.getJSON('http://cdn.api.twitter.com/1/urls/count.json?url=' + url + '&callback=?', function (twitdata) {
			jQuery('.twitter .count').text(number_format(twitdata.count));
			jQuery('.twitter').attr('data-count',twitdata.count);
		});
	
		// Get the LinkedIn Count
		jQuery.getJSON('http://www.linkedin.com/countserv/count/share?url=' + url + '&callback=?', function (linkdindata) {
			jQuery('.linkedIn .count').text(number_format(linkdindata.count));
			jQuery('.linkedIn').attr('data-count',linkdindata.count);
		});
		
		// Get Facebook Shares
		jQuery.getJSON('http://graph.facebook.com/?id=' + url + '&callback=?', function (facebook) {
			if( facebook.shares == undefined) { facebook.shares = 0 };
			jQuery('.fb .count').text(number_format(facebook.shares));		
			jQuery('.fb').attr('data-count',facebook.shares);	
		});
		
		// Get Pinterest Pins
		jQuery.getJSON('http://api.pinterest.com/v1/urls/count.json?url=' + url + '&callback=?', function (pins) {
			jQuery('.nc_pinterest .count').text(number_format(pins.count));
			jQuery('.nc_pinterest').attr('data-count',pins.count);				
		});
}

function getShares(url) {
		
	// Activate All Other Functions
	// createTotal();
	createFloatBar();
	setWidths();
	floatingBar();
	activateHoverStates();
}

jQuery(document).ready(function() {

	// Adjusts widths when the window is resized
	jQuery(window).resize(function() {
		setWidths(true);	
	});
	
	var url = jQuery('.nc_socialPanel').attr('data-url');
	getShares(url);
	
});