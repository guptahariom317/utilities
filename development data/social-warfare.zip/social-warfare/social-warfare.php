<?php 
/*
	Plugin Name: Social Warfare
	Plugin URI: http://warfareplugins.com
	Description: A plugin to maximize social shares and kill the competition.
	Version: 0.4.22
	Author: Nicholas Z. Cardot - Dustin W. Stout - Jason T. Wiser
	Author URI: http://warfareplugins.com
*/

/*****************************************************************
*                                                                *
*          OPTIONS: DEFINING OPTIONS PAGES AND SETTINGS          *
*                                                                *
******************************************************************/
	define('DISABLE_CACHE', true);
	
	// Define the version that we are on
	$pluginVersion = '0.4.22';

	// $regCode = md5(get_home_url());

	// Re-define meta box path and URL
	$pluginUrl = '/wp-content/plugins/social-warfare';
	$pluginDir = dirname(__FILE__);

	define( 'RWMB_URL', trailingslashit( $pluginUrl.'/meta-box' ) );
	define( 'RWMB_DIR', trailingslashit( $pluginDir.'/meta-box' ) );
	define( 'PLUGIN_DIR',$pluginUrl);

	// Include the meta box script
	require_once RWMB_DIR . 'meta-box.php';
	require_once $pluginDir.'/newSettings.php';
	require_once $pluginDir.'/widgets.php';
	require_once $pluginDir.'/updates/plugin-update-checker.php';
	require_once $pluginDir.'/clickToTweet/clickToTweet.php';

	// Check for updates
	$MyUpdateChecker = new PluginUpdateChecker(
		'http://beta.warfareplugins.com/wp-content/plugins/social-warfare/social-warfare.json',
		__FILE__,
		'social-warfare',
		1
	);

	// Add settings link on plugin page
	function settingsLink($links) { 
	  $settings_link = '<a href="options-general.php?page=social-warfare">Settings</a>'; 
	  array_unshift($links, $settings_link); 
	  return $links; 
	}


	$plugin = plugin_basename(__FILE__);
	add_filter("plugin_action_links_$plugin", 'settingsLink' );

	// Check if we have a premium code or not

	// Get the options...or create them if they don't exist
	$options = get_option('socialWarfareOptions');
	if(!$options['locationPost']) 	{ $options['locationPost'] 	= 'both'; 	};
	if(!$options['locationPage']) 	{ $options['locationPage'] 	= 'both'; 	};
	if(!$options['locationSite']) 	{ $options['locationSite'] 	= 'both'; 	};
	if(!isset($options['googlePlus'])) 	{ $options['googlePlus'] 	= true; 	};
	if(!isset($options['twitter'])) 		{ $options['twitter'] 		= true; 	};
	if(!isset($options['facebook'])) 		{ $options['facebook'] 		= true; 	};
	if(!isset($options['pinterest'])) 		{ $options['pinterest'] 	= true; 	};
	if(!isset($options['linkedIn'])) 		{ $options['linkedIn'] 		= true; 	};
	if(!isset($options['totes'])) 			{ $options['totes'] 		= true; 	};
	if(!$options['twitterID']) 		{ $options['twitterID'] 	= false; 	};
	if(!$options['visualTheme']) 	{ $options['visualTheme'] 	= 'style1'; };
	if(!$options['cttTheme']) 		{ $options['cttTheme'] 		= 'style1'; };
	if(!$options['colorSet']) 		{ $options['colorSet'] 		= 'fade'; 	};
	if(!isset($options['float'])) 	{ $options['float'] 		= true; 	};
	if(!$options['floatOption']) 	{ $options['floatOption'] 	= 'bottom'; };
	if(!$options['floatBgColor']) 	{ $options['floatBgColor'] 	= '#ffffff';};
	if(!$options['swDecimals']) 	{ $options['swDecimals'] 	= 0;		};
	if(!$options['orderOfIcons']) 	{ $options['orderOfIcons'] 	= array(
		"Twitter" => "Twitter", 
		"LinkedIn" => "LinkedIn", 
		"Pinterest" => "Pinterest",
		"Facebook" => "Facebook", 
		"googlePlus" => "Google Plus"
		); 
	};
	
	function is_sw_registered() {
		$options = get_option('socialWarfareOptions');
		$regCode = md5(get_home_url());
		if(isset($options['premiumCode'])):
			if(md5($regCode) == $options['premiumCode']):	
				return TRUE;
			else:
				return FALSE;
			endif;
		else:
			return FALSE;
		endif;
	}
	
		
	function my_admin_notice() {
		if(!is_sw_registered()):
			echo '<div class="error">';
			echo '<p>'. __( 'You need to register your copy of Social Warfare in order to begin displaying it on your site. Navigate to the <a href="/wp-admin/admin.php?page=social-warfare"><b>Social Warfare Settings Page</b></a> and select the "Register" tab to register now! If you were an early beta tester and have not purchased a license from WarfarePlugins.com, please contact Nicholas Cardot at nick@sitesketch101.com. He will provide you with the instructions that you need to get your copy licensed. Unregistered versions of this plugin will lose a variety of features on November 1, 2014.', 'my-text-domain' ).'</p>';
			echo '</div>';
		endif; 
	}
	// add_action( 'admin_notices', 'my_admin_notice' );

	$style = $options['visualTheme'];
	wp_register_style( 'social_warfare', PLUGIN_DIR.'/css/'.$style.'.css',array(),$pluginVersion );
	wp_enqueue_style( 'social_warfare' );
	if(is_admin()):
		wp_register_style( 'mcecss', PLUGIN_DIR.'/clickToTweet/assets/css/admin.css',array(),$pluginVersion );
		wp_enqueue_style( 'mcecss' );
	else:
		if($options['cttTheme'] != 'none'):
			wp_register_style('clickToTweet', plugins_url('/clickToTweet/assets/css/'.$options['cttTheme'].'.css', __FILE__));
			wp_enqueue_style('clickToTweet');
		endif;
		wp_enqueue_script( 'social_warfare_script', PLUGIN_DIR . '/script.js',array( 'jquery' ),$pluginVersion);
	endif;


	add_filter( 'rwmb_meta_boxes', 'nc_register_meta_boxes' );
	function nc_register_meta_boxes( $meta_boxes )
	{
		 $prefix = 'nc_';
		 // 1st meta box
		 $meta_boxes[] = array(
			  'id'       => 'socialWarfare', 
			  'title'    => 'Social Warfare Custom Options',
			  'pages'    => array( 'post', 'page' ),
			  'context'  => 'normal',
			  'priority' => 'high',
			  'fields' => array(
					array(
						 'name'  => 'Social Media Image',
						 'desc'  => 'Add an image that will be used for the open graph meta tags which will be used for Facebook, LinkedIn, and Google Plus. If nothing is provided here, we will use the post thumbnail as a backup.',
						 'id'    => $prefix . 'ogImage',
						 'type'  => 'image_advanced',
						 'clone' => false,
					),
					array(
						 'name'  => 'Social Media Title',
						 'desc'  => 'Add a title that will be used for the open graph meta tag which will be used for Facebook, LinkedIn, and Google Plus. If nothing is provided here, we will use the post title as a backup.',
						 'id'    => $prefix . 'ogTitle',
						 'type'  => 'textarea',
						 'clone' => false,
					),
					array(
						 'name'  => 'Social Media Description',
						 'desc'  => 'Add a title that will be used for the open graph meta tag which will be used for Facebook, LinkedIn, and Google Plus.',
						 'id'    => $prefix . 'ogDescription',
						 'type'  => 'textarea',
						 'clone' => false,
					),
					array(
						 'name'  => 'Pinterest Optimized Image',
						 'desc'  => 'Add an image that is optimized for maximum exposure on Pinterest. We recommend 600px by 900px.',
						 'id'    => $prefix . 'pinterestImage',
						 'type'  => 'image_advanced',
						 'clone' => false,
					),
					array(
						 'name'  => 'Pinterest Description',
						 'desc'  => 'Place a customized message that will be used when this post is shared on Pinterest. Leave this blank to use the title of the post.',
						 'id'    => $prefix . 'pinterestDescription',
						 'type'  => 'textarea',
						 'clone' => false,
					),
					array(
						 'name'  => 'Custom Tweet',
						 'desc'  => 'Add a customized tweet. If this is left blank, the title of the post will be used. I recommend that you use a tool like Tweetdeck to craft a tweet with an image (to maximize visibility) and then copy/paste that tweet into here. This will prepoluate the share box when your site visitors click the tweet button.',
						 'id'    => $prefix . 'customTweet',
						 'type'  => 'textarea',
						 'clone' => false,
					),
					array(
						 'name'  => 'Location on Post',
						 'desc'  => 'Where would you like to have the share buttons displayed on this post? Leave this option on "default" to use the settings you have selected on the Social Warfare settings page.',
						 'id'    => $prefix . 'postLocation',
						 'type'  => 'select',
						 'options' => array(
						 	'default' => 'Default',
							'above'=>'Above the Content',
							'below' => 'Below the Content', 
							'both' => 'Both Above and Below the Content', 
							'none' => 'None/Manual Placement'),
						 'clone' => false,
					)
			  )
		 );
		 return $meta_boxes;
	}



/*****************************************************************
*                                                                *
*          THE ASSET CLASS: GETTING THE STATS                    *
*                                                                *
******************************************************************/

	// Function to contact foreign servers
	class shareCount {
		private $url,$timeout;
		function __construct($url,$timeout=10) {
			$this->url=rawurlencode($url);
			$this->timeout=$timeout;
		}
		
		// Gather the Twitter Stats
		function get_tweets() { 
			$json_string = $this->file_get_contents_curl('http://urls.api.twitter.com/1/urls/count.json?url=' . $this->url);
			$json = json_decode($json_string, true);
			return isset($json['count'])?intval($json['count']):0;
		}
		
		// Gather the LinkedIn Stats
		function get_linkedin() { 
			$json_string = $this->file_get_contents_curl("http://www.linkedin.com/countserv/count/share?url=$this->url&format=json");
			$json = json_decode($json_string, true);
			return isset($json['count'])?intval($json['count']):0;
		}
		
		// Gather the Facebook Stats
		function get_fb() {
			$json_string = $this->file_get_contents_curl('http://api.facebook.com/restserver.php?method=links.getStats&format=json&urls='.$this->url);
			$json = json_decode($json_string, true);
			return isset($json[0]['total_count'])?intval($json[0]['total_count']):0;
		}
		
		// Gather the Plus Ones
		function get_plusones()  {
			$curl = curl_init();
			curl_setopt($curl, CURLOPT_URL, "https://clients6.google.com/rpc");
			curl_setopt($curl, CURLOPT_POST, true);
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($curl, CURLOPT_POSTFIELDS, '[{"method":"pos.plusones.get","id":"p","params":{"nolog":true,"id":"'.rawurldecode($this->url).'","source":"widget","userId":"@viewer","groupId":"@self"},"jsonrpc":"2.0","key":"p","apiVersion":"v1"}]');
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
			$curl_results = curl_exec ($curl);
			curl_close ($curl);
			$json = json_decode($curl_results, true);
			return isset($json[0]['result']['metadata']['globalCounts']['count'])?intval( $json[0]['result']['metadata']['globalCounts']['count'] ):0;
		}
		
		// Gather the Pinterest Stats
		function get_pinterest() {
			$return_data = $this->file_get_contents_curl('http://api.pinterest.com/v1/urls/count.json?url='.$this->url);
			$json_string = preg_replace('/^receiveCount\((.*)\)$/', "\\1", $return_data);
			$json = json_decode($json_string, true);
			return isset($json['count'])?intval($json['count']):0;
		}
		private function file_get_contents_curl($url){
			$ch=curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
			curl_setopt($ch, CURLOPT_FAILONERROR, 1);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
			curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout);
			curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
			$cont = curl_exec($ch);
			if(curl_error($ch))
			{
				die(curl_error($ch));
			}
				return $cont;
			}
		}
		
// Create a function to round the thousands
function kilomega( $val ) {
	$options = get_option('socialWarfareOptions');
	if($val):
		if( $val < 1000 ): 
			return number_format($val);
		else: 
			$val = $val/1000; 
			return number_format($val,$options['swDecimals']).'K';
		endif;
	else:
		return 0;
	endif;
}

// The share buttons function
function socialWarfare($value=false,$where='default',$echo = true) { 

	// Get the options...or create them if they don't exist
	$options = get_option('socialWarfareOptions');
	if(!$options['locationPost']) 	{ $options['locationPost'] 	= 'both'; 	};
	if(!$options['locationPage']) 	{ $options['locationPage'] 	= 'both'; 	};
	if(!$options['locationSite']) 	{ $options['locationSite'] 	= 'both'; 	};
	if(!isset($options['googlePlus'])) 	{ $options['googlePlus'] 	= true; 	};
	if(!isset($options['twitter'])) 		{ $options['twitter'] 		= true; 	};
	if(!isset($options['facebook'])) 		{ $options['facebook'] 		= true; 	};
	if(!isset($options['pinterest'])) 		{ $options['pinterest'] 	= true; 	};
	if(!isset($options['linkedIn'])) 		{ $options['linkedIn'] 		= true; 	};
	if(!isset($options['totes'])) 			{ $options['totes'] 		= true; 	};
	if(!$options['twitterID']) 		{ $options['twitterID'] 	= false; 	};
	if(!$options['visualTheme']) 	{ $options['visualTheme'] 	= 'style1'; };
	if(!$options['cttTheme']) 		{ $options['cttTheme'] 		= 'style1'; };
	if(!$options['colorSet']) 		{ $options['colorSet'] 		= 'fade'; 	};
	if(!isset($options['float'])) 	{ $options['float'] 		= true; 	};
	if(!$options['floatOption']) 	{ $options['floatOption'] 	= 'bottom'; };
	if(!$options['floatBgColor']) 	{ $options['floatBgColor'] 	= '#ffffff';};
	if(!$options['swDecimals']) 	{ $options['swDecimals'] 	= 0;		};
	if(!$options['orderOfIcons']) 	{ $options['orderOfIcons'] 	= array(
		"Twitter" => "Twitter", 
		"LinkedIn" => "LinkedIn", 
		"Pinterest" => "Pinterest",
		"Facebook" => "Facebook", 
		"googlePlus" => "Google Plus"
		); 
	};
	
	if($value == false): $floatOption = 'floatNone'; 
	elseif(($options['float'] && is_single()) || ($options['float'] && is_page())): 
		$floatOption = 'float'.ucfirst($options['floatOption']); 
	else : 
		$floatOption = 'floatNone'; 
	endif;
	
	if (!is_feed() && get_post_status(get_the_ID()) == 'publish'):
		// Acquire the social stats from the networks
		$postID 			= get_the_ID();
	//	$url 				= 'http://dustn.tv/find-free-images/';
		$url 				= get_permalink( $postID );
		$title 			= strip_tags(get_the_title($postID));
		$title 			= str_replace('|','',$title);
	//	$description	= get_the_excerpt();
		$pi 				= rwmb_meta( 'nc_pinterestImage' , 'type=image');
		$pid				= rwmb_meta( 'nc_pinterestImage' );
		if($pid): $pi 	= '&media='.urlencode($pi[$pid]['full_url']);
		elseif(has_post_thumbnail( $post->ID )): $pi = '&media='.urlencode(wp_get_attachment_url( get_post_thumbnail_id($post->ID)));
		else: $pi		= '';
		endif;
		
		$pd				= rwmb_meta( 'nc_pinterestDescription' );
		$ct				= rwmb_meta( 'nc_customTweet' );
		$colorSet 		= $options['colorSet'];
		if(!$colorSet) { $colorSet = 'fullColor'; }
		
		$social 		= new shareCount($url);
		$totes = 0;
		
		// Cache the stats for faster load times
		
		$postAge = floor(date('U') - get_post_time('U'));
		if($postAge < (21 * 86400)): $hours = 1;
		elseif($postAge < (60 * 86400)): $hours = 3;
		else: $hours = 12;
		endif;
		$time = floor(((date('U')/60)/60));
		$time = $time - $hours;
		$lastChecked = get_post_meta($postID,'timestamp',true);
		
		if($lastChecked > ($time - $hours) && $lastChecked > 390000):
			if( $options['twitter'] ) 	$tweets  	= get_post_meta($postID,'tweets',true);
			if( $options['facebook'] ) 	$shares  	= get_post_meta($postID,'shares',true);
			if( $options['googlePlus'] )$plusses 	= get_post_meta($postID,'plusses',true);
			if( $options['pinterest'] ) $pins    	= get_post_meta($postID,'pins',true);
			if( $options['linkedIn'] ) 	$linkShares	= get_post_meta($postID,'linkShares',true);
			$totes									= get_post_meta($postID,'totes',true);
		
		else:
			if( $options['twitter'] ) 	$tweets  	= $social->get_tweets(); 	$totes += $tweets;
			if( $options['facebook'] ) 	$shares  	= $social->get_fb(); 		$totes += $shares;
			if( $options['googlePlus'] )$plusses 	= $social->get_plusones();	$totes += $plusses;
			if( $options['pinterest'] ) $pins    	= $social->get_pinterest(); $totes += $pins;
			if( $options['linkedIn'] ) 	$linkShares	= $social->get_linkedin();	$totes += $linkShares;
		
			update_post_meta($postID,'tweets',$tweets);
			update_post_meta($postID,'shares',$shares);
			update_post_meta($postID,'plusses',$plusses);
			update_post_meta($postID,'pins',$pins);
			update_post_meta($postID,'linkShares',$linkShares);
			update_post_meta($postID,'totes',$totes);
			update_post_meta($postID,'timestamp',$time);
		
		endif;
	
		// Count the number of active units
		$count = 0;
		if( $options['googlePlus'] ) 	++$count;
		if( $options['twitter'] ) 		++$count;
		if( $options['facebook'] ) 		++$count;		
		if( $options['pinterest'] ) 	++$count;
		if( $options['linkedIn'] ) 		++$count;
		if( $options['totes'] ) 		++$count;
					
		// Create the social panel
		$assets 		= '<div class="nc_socialPanel '.$colorSet.'" data-position="'.$options['locationPost'].'" data-float="'.$floatOption.'" data-count="'.$count.'" data-floatColor="'.$options['floatBgColor'].'" data-url="'.$url.'">';
	
		// Create the Google+ Box
		if( $options['googlePlus'] ):
			$resource['googlePlus'] = '<div class="nc_tweetContainer googlePlus" data-num="18" data-wid="45" data-id="1" data-count="'.$plusses.'">';
			$resource['googlePlus'] .= '<a target="_blank" data-link="https://plus.google.com/share?url='.$url.'" class="nc_tweet">';
			$resource['googlePlus'] .= '<span class="iconFiller"></span>';
			$resource['googlePlus'] .= '<span class="count">'.kilomega($plusses).'</span>';
			$resource['googlePlus'] .= '</a>';
			$resource['googlePlus'] .= '</div>';
		endif; 
			
		// Create the Twitter Box
		if( $options['twitter'] ):
			$ct = ($ct != '' ? urlencode($ct) : $title);
			if (strpos($ct,'http') !== false) : $urlParam = '&url=/'; else: $urlParam = '&url='.$url; endif;
			if($options['twitterID']): $viaText = '&via='.$options['twitterID']; else: $viaText = ''; endif;
			$resource['Twitter'] = '<div class="nc_tweetContainer twitter" data-num="40" data-wid="70" data-id="2" data-count="0">';
			$resource['Twitter'] .= '<a data-link="https://twitter.com/share?original_referer=/&text='.$ct.''.$urlParam.''.$viaText.'" class="nc_tweet">';
			$resource['Twitter'] .= '<span class="iconFiller"></span>';
			$resource['Twitter'] .= '<span class="count">'.kilomega($tweets).'</span>';
			$resource['Twitter'] .= '</a>';
			$resource['Twitter'] .= '</div>';
		endif;
		
		// Create the Facebook Box
		if( $options['facebook'] ):
			$resource['Facebook'] = '<div class="nc_tweetContainer fb" data-num="30" data-wid="55" data-id="3" data-count="0">';
			$resource['Facebook'] .= '<a target="_blank" data-link="http://www.facebook.com/share.php?u='.$url.'" class="nc_tweet">';
			$resource['Facebook'] .= '<span class="iconFiller"></span>';
			$resource['Facebook'] .= '<span class="count">'.kilomega($shares).'</span>'; 
			$resource['Facebook'] .= '</a>';
			$resource['Facebook'] .= '</div>';
		endif;
		
		// Create the Pinterest Box
		if( $options['pinterest'] ):
			if($pi != ''): $a = '<a data-link="http://pinterest.com/pin/create/button/?url='.urlencode($url).''.$pi.'&description='.($pd != '' ? urlencode($pd) : urlencode($title)).'" class="nc_tweet" data-count="0">';
			else: $a = '<a onClick="var e=document.createElement(\'script\');e.setAttribute(\'type\',\'text/javascript\');e.setAttribute(\'charset\',\'UTF-8\');e.setAttribute(\'src\',\'http://assets.pinterest.com/js/pinmarklet.js?r=\'+Math.random()*99999999);document.body.appendChild(e);" class="nc_tweet noPop">';
			endif;
			$resource['Pinterest'] = '<div class="nc_tweetContainer nc_pinterest" data-num="25" data-wid="55" data-id="4">';
			$resource['Pinterest'] .= $a;
			$resource['Pinterest'] .= '<span class="iconFiller"></span>';
			$resource['Pinterest'] .= '<span class="count">'.kilomega($pins).'</span>';
			$resource['Pinterest'] .= '</a>';
			$resource['Pinterest'] .= '</div>';
		endif;
	
		// Create the Linked In Box
		if( $options['linkedIn'] ):
			$resource['LinkedIn'] .= '<div class="nc_tweetContainer linkedIn" data-num="41" data-wid="70" data-id="5" data-count="0">';
			$resource['LinkedIn'] .= '<a data-link="https://www.linkedin.com/cws/share?url='.$url.'" class="nc_tweet">';
			$resource['LinkedIn'] .= '<span class="iconFiller"></span>';
			$resource['LinkedIn'] .= '<span class="count">'.kilomega($linkShares).'</span>'; 
			$resource['LinkedIn'] .= '</a>';
			$resource['LinkedIn'] .= '</div>';
		endif;
	
		foreach($options['orderOfIcons'] as $thisIcon => $status):
			$assets .= $resource[$thisIcon];
		endforeach;
	
		// Create the Total Shares Box
		if( $options['totes'] ):
			$assets .= '<div class="nc_tweetContainer totes" data-id="6">';
			$assets .= '<span class="count">'.kilomega($totes).' SHARES</span>'; 
			$assets .= '</div>';
		endif;
			
		// Close the Social Panel
		$assets .= '</div>';
		
		// Check to see if display location was specifically defined for this post
		$specWhere = rwmb_meta( 'nc_postLocation' );
		if($where == 'default'):
			if($specWhere == 'default' || $specWhere == ''):
				if( is_singular('post') ):
					$where = $options['locationPost'];
				elseif( is_singular('page') ):
					$where = $options['locationPage'];
				else:
					$where = $options['locationSite'];
				endif;
			else:
				$where = $specWhere;
			endif;
		endif;
		
		if($echo == false && $where != 'none'):
			return $assets;
		elseif($value === false):
			echo $assets;
		elseif($where	== 'below'):
			$value 		= $value.''.$assets;
			return $value;
		elseif($where 	== 'above'):
			$value 		= $assets.''.$value;
			return $value;
		elseif($where 	== 'both'):
			$value 		= $assets.''.$value.''.$assets;
			return $value;
		elseif($where  	== 'none'):
			return $value;
		endif;
	else:
		return $value;
	endif;
	
 }

		
		
		
	function addImages() {
			
		echo PHP_EOL .'<!-- Open Graph Meta Tags generated by Social Warfare http://warfareplugins.com -->';
		
		// Get the POST ID
		$postID 		= get_the_ID();
		
		// Create the image Open Graph Meta Tag
		$image			= rwmb_meta( 'nc_ogImage', 'type=image' );
		$imageID		= rwmb_meta( 'nc_ogImage' );
		$imageURL		= $image[$imageID]['full_url'];
		if($imageURL):
			echo PHP_EOL .'<meta property="og:image" content="'.$imageURL.'" />';
			if (defined('WPSEO_VERSION')):
			    global $wpseo_og;
   				remove_action( 'wpseo_opengraph', array( $wpseo_og, 'image' ), 30 );
			endif;
		elseif(has_post_thumbnail( $postID ) && !defined('WPSEO_VERSION')):
			$image = wp_get_attachment_url( get_post_thumbnail_id($postID));
			echo PHP_EOL .'<meta property="og:image" content="'.$image.'" />';
		endif;
		
		// Create the Title Open Graph Meta Tag
		$title = rwmb_meta( 'nc_ogTitle' );
		if($title):
			echo PHP_EOL .'<meta property="og:title" content="'.$title.'" />';
			if (defined('WPSEO_VERSION')):
			    global $wpseo_og;
   				remove_action( 'wpseo_opengraph', array( $wpseo_og, 'og_title' ), 10 );
			endif;
		elseif(!defined('WPSEO_VERSION')):
			$title = get_the_title();
			echo PHP_EOL .'<meta property="og:title" content="'.$title.'" />';
		endif;
		
		
		// Create the description Open Graph Meta Tag
		$description = rwmb_meta( 'nc_ogDescription' );
		if($description):
			echo PHP_EOL .'<meta property="og:description" content="'.$description.'" />';
			if (defined('WPSEO_VERSION')):
			    global $wpseo_og;
   				remove_action( 'wpseo_opengraph', array( $wpseo_og, 'description' ), 11 );
			endif;
		endif;
		
		// Other Important Open Graph Meta Data
		echo PHP_EOL .'<meta property="og:url" content="'.get_the_permalink().'" />';
		echo PHP_EOL .'<meta property="og:site_name" content="'.get_bloginfo('name').'" />';
	}

	add_filter('the_content', 'socialWarfare', 20);
	add_filter('the_excerpt', 'socialWarfare', 20);
	add_action('wp_head','addImages',1);

	function socialWarfareShortcode( $atts ){
		return socialWarfare(false,'after',false);
	}
	
	add_shortcode( 'socialWarfare', 'socialWarfareShortcode' );

?>