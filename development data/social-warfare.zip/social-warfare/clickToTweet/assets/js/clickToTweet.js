(function() {
    tinymce.PluginManager.add('clickToTweet', function( editor, url ) {
        editor.addButton( 'clickToTweet', {
            title: 'Add a Click to Tweet Courtesy of Social Warfare',
            icon: 'icon dashicons-twitter',
            onclick: function() {
				editor.windowManager.open( {
					title: 'Build Your "Click to Tweet"',
					body: [
						{
							type: 'textbox',
							name: 'tweet',
							size: 80,
							label: 'The Tweet that will be sent out on Twitter.',
							onkeyup: function() {
								var value = jQuery('.mce-first input').val();
								var strLength = value.length;
								var remaining = 117 - strLength;
								if(remaining > 1 || remaining == 0) {
									jQuery('.tweetCounter').css({'color':'green'}).text(remaining + ' characters');	
								} else if (remaining == 1) {
									jQuery('.tweetCounter').css({'color':'green'}).text(remaining + ' character');
								} else if (remaining < 0) {
									jQuery('.tweetCounter').css({'color':'red'}).text(remaining + ' characters');	
								}
							},
							class: 'tweetCounting'
						},
						{
							type: 'label',
							name: 'someHelpText',
							onPostRender : function() {
								this.getEl().innerHTML =
								   '<span style="float:right;">You have <span class="tweetCounter" style="color:green">117 characters</span> remaining.</span>';},
							text: ''},
						{
							type: 'textbox',
							size: 80,
							name: 'quote',
							label: 'The quote as it will appear in your article.'
						},{
							type: 'label',
							name: 'someHelpText2',
							onPostRender : function() {
								this.getEl().innerHTML =
								   '<b>IMPORTANT NOTE:</b> Do NOT include any quotation marks inside these fields or the shortcode that it generates will not function properly.';},
							text: ''}
					],
					onsubmit: function( e ) {
						var value = jQuery('.mce-first input').val();
						var strLength = value.length;
						var remaining = 117 - strLength;
						if(e.data.tweet === '' || e.data.quote === '') {
        					editor.windowManager.alert('Please, fill in both fields.');
							return false;
						} else if(remaining < 0) {
       		 				editor.windowManager.alert('You have too many characters in your tweet.');
							return false;
						}
						editor.insertContent( '[clickToTweet tweet="' + e.data.tweet + '" quote="' + e.data.quote + '"]');
					}
				});
			}
        });
    });
})();